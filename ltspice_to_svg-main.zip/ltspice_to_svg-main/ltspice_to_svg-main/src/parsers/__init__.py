"""
Parsers for LTspice files.
""" 